3:"$Sreact.fragment"
4:I[7121,[],""]
5:I[4581,[],""]
a:"static/chunks/1163-c02fa5eacb66a7db.js"
b:"static/chunks/app/(site)/contact/page-b90c470fa0c42e47.js"
c:I[4216,["1163","$a","7474","$b"],"ContactForm"]
d:I[484,[],"OutletBoundary"]
e:"$Sreact.suspense"
11:"ViewportBoundary"
12:I[484,[],"$11"]
13:"MetadataBoundary"
14:I[484,[],"$13"]
7:X
7:C
8:X
9:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$3","c",{"children":[["$","div",null,{"className":"container-editorial py-16","children":[["$","div",null,{"className":"max-w-2xl","children":[["$","span",null,{"className":"gold-rule block mb-5"}],["$","h1",null,{"className":"font-display text-4xl text-primary-deep","children":"Get in touch"}],["$","p",null,{"className":"mt-3 text-muted","children":"Questions about an order, a product, or wholesale? Send us a message and we’ll reply within 1–2 business days."}]]}],["$","div",null,{"className":"mt-12 grid grid-cols-1 md:grid-cols-[1fr_320px] gap-12","children":[["$","$Lc",null,{}],["$","aside",null,{"className":"space-y-6 text-sm","children":[null,null,false]}]]}]]}],null,["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":"$@10","v":null,"s":"$8"}}]]
2:[["children",{"s":"contact","h":64,"d":{"r":["$","$3","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]}],"p":"$@6","v":"$7","s":"$8"},"c":"$Q9"}]]
1:[["children",{"s":"(site)","h":36,"c":"$Q2"}]]
0:{"t":{"t":{"s":"","h":88,"c":"$Q1"},"h":{"r":["$","$3","h",{"children":[null,["$","$L12",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Contact | DASDUM"}],["$","meta","1",{"name":"description","content":"Get in touch with the DASDUM team."}],["$","meta","2",{"name":"google-site-verification","content":"gLFpVj7jfeGz8FOtoI3zf34ku43DUBBeBjpKUwwhK4o"}],["$","meta","3",{"property":"og:title","content":"Contact | DASDUM"}],["$","meta","4",{"property":"og:description","content":"Get in touch with the DASDUM team."}],["$","meta","5",{"property":"og:site_name","content":"DASDUM"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","8",{"name":"twitter:title","content":"Contact | DASDUM"}],["$","meta","9",{"name":"twitter:description","content":"Get in touch with the DASDUM team."}]]}]}],null]}],null]}],"p":"$@15","v":null,"s":"$8"}},"a":"$@16","u":"$@17","b":"jJUX6rQPhTV9BoLEVjkgA"}
f:null
17:true
8:300
8:C
16:0
6:"$undefined"
15:"$undefined"
10:"$undefined"
