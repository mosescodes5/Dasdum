1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
8:I[1304,[],"ClientPageRoot"]
9:"static/chunks/1163-c02fa5eacb66a7db.js"
a:"static/chunks/600-cc03813925fd406f.js"
b:"static/chunks/app/admin/login/page-26b28732a20b9808.js"
c:I[6080,["1163","$9","600","$a","2116","$b"],"default"]
f:I[484,[],"OutletBoundary"]
10:"$Sreact.suspense"
12:"ViewportBoundary"
13:I[484,[],"$12"]
15:"MetadataBoundary"
16:I[484,[],"$15"]
18:I[7123,[],"default",1]
:HL["/_next/static/css/a99c20d49b567aad.css","style"]
:HL["/_next/static/css/ab36b0cac5bbe520.css","style"]
5:X
7:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$L8",null,{"Component":"$c","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@d","$@e"]}}],null,["$","$Lf",null,{"children":["$","$10",null,{"name":"Next.MetadataOutlet","children":"$@11"}]}]]}],"p":false,"v":null}}]]
6:[["children",{"s":"login","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$5"},"c":"$Q7"}]]
4:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$5"},"c":"$Q6"}]]
0:{"P":null,"c":["","admin","login"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/a99c20d49b567aad.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/ab36b0cac5bbe520.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"__variable_980b0d __variable_eafbbb","children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":false,"v":null},"c":"$Q4"},"h":{"r":["$","$1","h",{"children":[null,["$","$L13",null,{"children":"$L14"}],["$","$L16",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$10",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$18",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"8BTwqkpWTUu7jdzM-BTET"}
5:C
d:{}
e:"$7:0:1:d:r:props:children:0:props:serverProvidedParams:params"
14:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
11:null
17:[["$","title","0",{"children":"DASDUM — Designed with purpose. Made for today."}],["$","meta","1",{"name":"description","content":"DASDUM is a modern African brand crafting thoughtful, quality-first goods for everyday living."}],["$","meta","2",{"name":"google-site-verification","content":"gLFpVj7jfeGz8FOtoI3zf34ku43DUBBeBjpKUwwhK4o"}],["$","meta","3",{"property":"og:title","content":"DASDUM — Designed with purpose. Made for today."}],["$","meta","4",{"property":"og:description","content":"DASDUM is a modern African brand crafting thoughtful, quality-first goods for everyday living."}],["$","meta","5",{"property":"og:site_name","content":"DASDUM"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","8",{"name":"twitter:title","content":"DASDUM — Designed with purpose. Made for today."}],["$","meta","9",{"name":"twitter:description","content":"DASDUM is a modern African brand crafting thoughtful, quality-first goods for everyday living."}]]
