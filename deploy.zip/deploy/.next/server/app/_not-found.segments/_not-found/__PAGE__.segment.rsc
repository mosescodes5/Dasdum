1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
a:I[484,[],"OutletBoundary"]
b:"$Sreact.suspense"
e:"ViewportBoundary"
f:I[484,[],"$e"]
10:"MetadataBoundary"
11:I[484,[],"$10"]
:HL["/_next/static/css/a99c20d49b567aad.css","style"]
:HL["/_next/static/css/ab36b0cac5bbe520.css","style"]
5:X
8:X
8:C
9:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],null,["$","$La",null,{"children":["$","$b",null,{"name":"Next.MetadataOutlet","children":"$@c"}]}]]}],"p":"$@d","v":null,"s":"$5"}}]]
6:[["children",{"s":"_not-found","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"p":"$@7","v":"$8","s":"$5"},"c":"$Q9"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/a99c20d49b567aad.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/ab36b0cac5bbe520.css","precedence":"next"}]],["$","html",null,{"lang":"en","className":"__variable_980b0d __variable_eafbbb","children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]}]]}],"p":"$@4","v":null,"s":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$Lf",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L11",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$b",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"DASDUM — Designed with purpose. Made for today."}],["$","meta","1",{"name":"description","content":"DASDUM is a modern African brand crafting thoughtful, quality-first goods for everyday living."}],["$","meta","2",{"name":"google-site-verification","content":"gLFpVj7jfeGz8FOtoI3zf34ku43DUBBeBjpKUwwhK4o"}],["$","meta","3",{"property":"og:title","content":"DASDUM — Designed with purpose. Made for today."}],["$","meta","4",{"property":"og:description","content":"DASDUM is a modern African brand crafting thoughtful, quality-first goods for everyday living."}],["$","meta","5",{"property":"og:site_name","content":"DASDUM"}],["$","meta","6",{"property":"og:type","content":"website"}],["$","meta","7",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","8",{"name":"twitter:title","content":"DASDUM — Designed with purpose. Made for today."}],["$","meta","9",{"name":"twitter:description","content":"DASDUM is a modern African brand crafting thoughtful, quality-first goods for everyday living."}]]}]}],null]}],null]}],"p":"$@12","v":null,"s":"$5"}},"a":"$@13","u":"$@14","b":"8BTwqkpWTUu7jdzM-BTET"}
c:null
5:300
14:true
5:C
13:0
7:"$undefined"
4:"$undefined"
12:"$undefined"
d:"$undefined"
